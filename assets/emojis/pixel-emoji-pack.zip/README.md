# Pixel Emoji Pack

This pack contains 50 unique 128x128 pixel emoji images. Redundant command names use the closest matching canonical emoji instead of storing duplicate images. The archive is available at `C:\Users\tra33\discord_pixel_emoji.zip`. To recreate the images locally, run:

```sh
node scripts/emoji-tools/generate-banhcuon-pixel-emoji-pack.mjs
```

`generate-pixel-emoji-pack.mjs` delegates to the branded generator. It removes stale or redundant PNG files from this folder before generating the canonical set. Additional command and Minecraft symbols use the closest matching uploaded emoji as aliases.

Upload generated PNG files in Discord under **Server Settings → Emoji**. Discord may resize uploaded emoji automatically.

To upload the set, set `DISCORD_TOKEN` and `GUILD_ID` in the local `.env` file, then run:

```sh
node scripts/emoji-tools/upload-pixel-emoji-pack.mjs
```

To delete every custom emoji in the server without uploading replacements, run:

```sh
node scripts/emoji-tools/upload-pixel-emoji-pack.mjs --delete-all
```

`--replace-all` deletes every custom emoji in that server, including emoji used by other people or messages; those cannot be restored by this script. It validates all PNGs and permissions before deleting, then uploads the set as `bc_*` emoji and writes IDs to `emoji-ids.json`. Restart the bot after upload. The shared emoji config uses the branded set for command aliases, and the command-response middleware converts Unicode emoji in command replies, embeds, buttons, and select options to the branded set. The bot needs permission to manage server emoji.
